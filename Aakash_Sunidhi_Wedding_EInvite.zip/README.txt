Aakash & Sunidhi Wedding E-Invite
=================================

Files:
- index.html — complete mobile-friendly wedding website.

FREE HOSTING — GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a new PUBLIC repository, e.g. aakash-sunidhi-wedding.
3. Upload index.html.
4. Repository Settings → Pages → Deploy from branch → main → / (root) → Save.
5. GitHub will provide the free website URL.

RSVP:
The current RSVP button opens the generic Google Forms page. Create your own Google Form and replace:
https://forms.google.com/
inside index.html with your form's public link.

NOTES:
- Google Maps buttons already use Google Maps search URLs for the two venues.
- Countdown is set to 19 October 2026 at 7:00 PM IST.
- Fonts load from Google Fonts when internet is available.
